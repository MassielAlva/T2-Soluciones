package com.lectorium.service;

import com.lectorium.model.Author;

public interface IAuthorService extends IGenericService<Author, Integer> {
}
