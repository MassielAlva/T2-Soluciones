package com.lectorium.repo;

import com.lectorium.model.Category;

public interface ICategoryRepo extends IGenericRepo<Category, Integer> {
}
