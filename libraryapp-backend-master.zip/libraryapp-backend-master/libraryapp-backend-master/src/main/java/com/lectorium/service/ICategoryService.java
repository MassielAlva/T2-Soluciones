package com.lectorium.service;

import com.lectorium.model.Category;

public interface ICategoryService extends IGenericService<Category, Integer> {
}
