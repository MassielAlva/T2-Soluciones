package com.lectorium.repo;

import com.lectorium.model.Author;

public interface IAuthorRepo extends IGenericRepo<Author, Integer> {
}
