package com.lectorium.repo;

import org.springframework.stereotype.Repository;

import com.lectorium.model.Publisher;

@Repository
public class PublisherRepoImpl{ //implements IPublisherRepo{
	/*@Override
	public Publisher save(Publisher publisher) {
		System.out.println("Publisher save to database");
		return publisher;
	}
	*/
}
