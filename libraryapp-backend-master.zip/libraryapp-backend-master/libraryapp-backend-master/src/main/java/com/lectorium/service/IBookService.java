package com.lectorium.service;

import com.lectorium.model.Book;

public interface IBookService extends IGenericService<Book, Integer> {
}
