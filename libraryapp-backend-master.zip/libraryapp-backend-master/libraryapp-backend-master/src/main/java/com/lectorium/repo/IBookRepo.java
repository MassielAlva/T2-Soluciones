package com.lectorium.repo;

import com.lectorium.model.Book;

public interface IBookRepo extends IGenericRepo<Book, Integer> {
}
