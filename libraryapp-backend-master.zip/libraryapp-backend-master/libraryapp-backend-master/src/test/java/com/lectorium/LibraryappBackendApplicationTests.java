package com.lectorium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryappBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
