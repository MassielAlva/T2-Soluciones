import { Component } from '@angular/core';

@Component({
  selector: 'app-category-edit',
  imports: [],
  templateUrl: './category-edit.component.html',
  styleUrl: './category-edit.component.css'
})
export class CategoryEditComponent {

}
