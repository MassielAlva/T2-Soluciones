export class Publisher{
    idPublisher: number;
    name: string;
    address: string;
}