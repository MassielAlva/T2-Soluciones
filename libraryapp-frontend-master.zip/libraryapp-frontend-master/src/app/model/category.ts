export class Category {
  idCategory: number;
  name: string;
  description: string;
}
